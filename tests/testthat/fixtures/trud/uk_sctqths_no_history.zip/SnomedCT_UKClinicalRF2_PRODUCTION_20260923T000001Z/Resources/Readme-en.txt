Test release without a history table
